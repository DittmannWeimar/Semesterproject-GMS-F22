<div class="navbar-default" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">links toggle button</span>
            <span class="mdl-color--white white icon-bar"></span>
            <span class="mdl-color--white white icon-bar"></span>
            <span class="mdl-color--white icon-bar"></span>
        </button>
        <a href="/"><span class="navbar-brand">Green House Management System</span></a>
    </div>
    <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav" style="float: right;" id="navbar-categories">
        </ul>
    </div>
</div>
