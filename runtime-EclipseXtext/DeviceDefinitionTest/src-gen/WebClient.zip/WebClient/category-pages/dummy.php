<!DOCTYPE html>
<html>

<head>
    <title>Green House Management System</title>
    <?php require $_SERVER['DOCUMENT_ROOT'] . "/header.php" ?>
    <script src="dummy.js"></script>
</head>

<body>
    <?php require $_SERVER['DOCUMENT_ROOT'] . "/commonBody.php" ?>
    <ul class="flex-container">
<li class="chart-container">
    <div class="centered"><h3>Sin (time)</h3></div>
    <canvas id="chart-Sin (time)"></canvas>
    <div>
        <button id="chart-Sin (time)-all" class="btn btn-link" onclick="updateChart('chart-Sin (time)', ['samples/58:BF:25:E0:77:98/10:97:BD:D5:3E:64/dummy,zero'], Date.now())">All</button>
        <button id="chart-Sin (time)-year" class="btn btn-link" onclick="updateChart('chart-Sin (time)', ['samples/58:BF:25:E0:77:98/10:97:BD:D5:3E:64/dummy,zero'], 12*28*24*60*60*1000)">Last Year</button>
        <button id="chart-Sin (time)-month" class="btn btn-link" onclick="updateChart('chart-Sin (time)', ['samples/58:BF:25:E0:77:98/10:97:BD:D5:3E:64/dummy,zero'], 28*24*60*60*1000)">Last Month</button>
        <button id="chart-Sin (time)-week" class="btn btn-link" onclick="updateChart('chart-Sin (time)', ['samples/58:BF:25:E0:77:98/10:97:BD:D5:3E:64/dummy,zero'], 7*24*60*60*1000)">Last Week</button>
        <button id="chart-Sin (time)-24-hour" class="btn btn-link" onclick="updateChart('chart-Sin (time)', ['samples/58:BF:25:E0:77:98/10:97:BD:D5:3E:64/dummy,zero'], 24*60*60*1000)">24 Hours</button>
        <button id="chart-Sin (time)-last-hour" class="btn btn-link" onclick="updateChart('chart-Sin (time)', ['samples/58:BF:25:E0:77:98/10:97:BD:D5:3E:64/dummy,zero'], 60*60*1000)">Last Hour</button>
    </div>
</li>
    </ul>
</body>

</html>
